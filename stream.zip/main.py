"""Minimal web UI: upload one bank-statement PDF, see the extracted
transactions as a table, and download the CSV.

Run:
    python main.py
Then open http://127.0.0.1:5000 in a browser.
"""

from __future__ import annotations

import os
import tempfile

from flask import (
    Flask, request, render_template_string, send_from_directory, abort,
)

from ledger_extract.pipeline import extract_statement

app = Flask(__name__)

OUTPUT = os.path.join(os.path.dirname(__file__), "output_normalized")
UPLOADS = os.path.join(tempfile.gettempdir(), "ledgerit_uploads")
os.makedirs(OUTPUT, exist_ok=True)
os.makedirs(UPLOADS, exist_ok=True)

PASSWORD_MAP = {
    "HDFC_54212352.pdf": "54212352",
    "HDFC_bank_317016433.pdf": "317016433",
}

PAGE = """
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Statement Extractor</title>
<style>
  :root { --bg:#0f172a; --card:#1e293b; --line:#334155; --muted:#94a3b8;
          --dr:#f87171; --cr:#34d399; --accent:#60a5fa; }
  * { box-sizing: border-box; }
  body { margin:0; font-family: system-ui, Segoe UI, Roboto, sans-serif;
         background:#f1f5f9; color:#0f172a; }
  header { background:var(--bg); color:#fff; padding:18px 24px; }
  header h1 { margin:0; font-size:18px; font-weight:600; }
  header p { margin:4px 0 0; color:var(--muted); font-size:13px; }
  main { max-width:1150px; margin:24px auto; padding:0 16px; }
  .card { background:#fff; border:1px solid #e2e8f0; border-radius:10px;
          padding:18px 20px; margin-bottom:20px; box-shadow:0 1px 2px rgba(0,0,0,.04); }
  form { display:flex; gap:12px; align-items:center; flex-wrap:wrap; }
  input[type=file] { font-size:14px; }
  input[type=text] { padding:8px 10px; border:1px solid #cbd5e1; border-radius:6px; font-size:14px; }
  button { background:var(--accent); color:#fff; border:0; padding:9px 18px;
           border-radius:6px; font-size:14px; font-weight:600; cursor:pointer; }
  button:hover { background:#3b82f6; }
  .err { background:#fef2f2; border:1px solid #fecaca; color:#b91c1c;
         padding:12px 14px; border-radius:8px; }
  .meta { display:flex; flex-wrap:wrap; gap:10px 26px; font-size:14px; }
  .meta b { color:#475569; font-weight:600; }
  .pill { display:inline-block; padding:2px 9px; border-radius:999px; font-size:12px;
          font-weight:700; }
  .pill.dr { background:#fee2e2; color:#b91c1c; }
  .pill.cr { background:#dcfce7; color:#15803d; }
  .toolbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; }
  .toolbar a { color:var(--accent); font-weight:600; text-decoration:none; font-size:14px; }
  table { width:100%; border-collapse:collapse; font-size:13px; }
  th, td { text-align:left; padding:7px 10px; border-bottom:1px solid #eef2f7; }
  th { background:#f8fafc; position:sticky; top:0; color:#475569; font-weight:600; }
  td.num { text-align:right; font-variant-numeric:tabular-nums; }
  td.desc { max-width:430px; }
  tr:hover { background:#f8fafc; }
  .wrap { max-height:65vh; overflow:auto; border:1px solid #e2e8f0; border-radius:10px; }
  .muted { color:#64748b; font-size:13px; }
</style>
</head>
<body>
<header>
  <h1>Bank Statement → Transactions</h1>
  <p>Upload one statement PDF. Type (DR/CR) is derived from the running balance via Camelot stream.</p>
</header>
<main>
  <div class="card">
    <form method="post" action="/" enctype="multipart/form-data">
      <input type="file" name="pdf" accept="application/pdf" required>
      <input type="text" name="password" placeholder="password (optional)">
      <button type="submit">Extract</button>
    </form>
  </div>

  {% if error %}
    <div class="card"><div class="err">{{ error }}</div></div>
  {% endif %}

  {% if meta %}
  <div class="card">
    <div class="meta">
      <span><b>File:</b> {{ meta.file }}</span>
      <span><b>Bank:</b> {{ meta.bank }}</span>
      <span><b>Transactions:</b> {{ meta.n_txns }}</span>
      <span><b>DR:</b> {{ meta.n_dr }} &nbsp; <b>CR:</b> {{ meta.n_cr }}</span>
      <span><b>Sum debit:</b> {{ '{:,.2f}'.format(meta.sum_debit) }}</span>
      <span><b>Sum credit:</b> {{ '{:,.2f}'.format(meta.sum_credit) }}</span>
      <span><b>Opening:</b> {{ meta.opening_balance }}</span>
      <span><b>Closing:</b> {{ meta.closing_balance }}</span>
      <span><b>Untyped:</b> {{ meta.n_untyped }}</span>
      <span><b>Continuity breaks:</b> {{ meta.continuity_breaks }}</span>
    </div>
  </div>

  <div class="card">
    <div class="toolbar">
      <span class="muted">{{ rows|length }} rows</span>
      <a href="/download/{{ csv_name }}">⬇ Download CSV</a>
    </div>
    <div class="wrap">
      <table>
        <thead>
          <tr><th>#</th><th>Date</th><th>Description</th><th>Reference</th>
              <th class="num">Debit</th><th class="num">Credit</th>
              <th class="num">Balance</th><th>Type</th></tr>
        </thead>
        <tbody>
        {% for r in rows %}
          <tr>
            <td class="muted">{{ loop.index }}</td>
            <td>{{ r.Date }}</td>
            <td class="desc">{{ r.Description }}</td>
            <td class="muted">{{ r.Reference }}</td>
            <td class="num">{{ r.Debit }}</td>
            <td class="num">{{ r.Credit }}</td>
            <td class="num">{{ r.Balance }}</td>
            <td>{% if r.Type == 'DR' %}<span class="pill dr">DR</span>
                {% elif r.Type == 'CR' %}<span class="pill cr">CR</span>
                {% else %}<span class="muted">—</span>{% endif %}</td>
          </tr>
        {% endfor %}
        </tbody>
      </table>
    </div>
  </div>
  {% endif %}
</main>
</body>
</html>
"""


def _fmt(v):
    if v is None or v == "" or (isinstance(v, float) and v != v):  # NaN
        return ""
    if isinstance(v, float):
        return f"{v:,.2f}"
    return v


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "GET":
        return render_template_string(PAGE)

    f = request.files.get("pdf")
    if not f or not f.filename:
        return render_template_string(PAGE, error="No file selected.")
    if not f.filename.lower().endswith(".pdf"):
        return render_template_string(PAGE, error="Please upload a PDF file.")

    save_path = os.path.join(UPLOADS, os.path.basename(f.filename))
    f.save(save_path)

    pw = (request.form.get("password") or "").strip()
    pw_map = dict(PASSWORD_MAP)
    if pw:
        pw_map[os.path.basename(f.filename)] = pw

    try:
        df, meta = extract_statement(save_path, pw_map)
    except Exception as e:
        return render_template_string(PAGE, error=f"Extraction failed: {e}")

    csv_name = os.path.splitext(os.path.basename(f.filename))[0]
    csv_name = csv_name.replace("_unlocked", "") + ".csv"
    df.to_csv(os.path.join(OUTPUT, csv_name), index=False)

    rows = []
    for rec in df.to_dict("records"):
        rows.append({k: _fmt(v) for k, v in rec.items()})

    return render_template_string(PAGE, meta=meta, rows=rows, csv_name=csv_name)


@app.route("/download/<path:csv_name>")
def download(csv_name):
    if not os.path.exists(os.path.join(OUTPUT, csv_name)):
        abort(404)
    return send_from_directory(OUTPUT, csv_name, as_attachment=True)


if __name__ == "__main__":
    app.run(debug=True, port=5000)
